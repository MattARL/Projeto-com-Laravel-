<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Celke</title>
</head>

<body>

    <a href="<?php echo e(route('conta.index')); ?>">Listar</a><br>

    <h2>Editar a Conta</h2>

</body>

</html>
<?php /**PATH C:\wamp64\www\celke\resources\views/contas/edit.blade.php ENDPATH**/ ?>